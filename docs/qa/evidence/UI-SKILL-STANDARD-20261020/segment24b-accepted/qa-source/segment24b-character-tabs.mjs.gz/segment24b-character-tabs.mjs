import fs from 'node:fs';
import os from 'node:os';
import crypto from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
import {ROOT,startServer,waitJson,Cdp,findChrome} from '../.github/scripts/runtime-browser-qa-support.mjs';

// Use the same isolated account and the real production loader as skill QA.
const skillQa=fs.readFileSync(path.join(ROOT,'.github/scripts/run-skill-progression-browser-qa.mjs'),'utf8');
const prepare=skillQa.match(/const PREPARE_RUNTIME=`([\s\S]*?)`;/)[1];
const viewport=JSON.parse(process.env.UI_READING_VIEWPORT||'[393,873]');
const sourceHead=process.env.GITHUB_SHA||execFileSync('git',['rev-parse','HEAD'],{cwd:ROOT,encoding:'utf8'}).trim();
const sourceDirty=!!execFileSync('git',['status','--porcelain'],{cwd:ROOT,encoding:'utf8'}).trim();
const out=path.join(ROOT,'artifacts/ui-skill-standard/segment24b-character-tabs-'+sourceHead.slice(0,8)+'/prepared',viewport.join('x'));if(fs.existsSync(out))throw Error('Output exists');
fs.mkdirSync(out,{recursive:true});
const hash=()=>Object.fromEntries(['index.html','asset-manifest.json','js/41-v146-system-polish.js','css/49-v169-rpg-ui.css','js/49-v169-element-box-settings.js','js/25-v131-fix-batch.js','js/00-main.js','css/48-v169-element-box-settings.css',...fs.readdirSync('build').filter(x=>/\.(css|js)$/.test(x)).map(x=>'build/'+x)].map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')]));const sourcesBefore=hash(),touches=[],checks=[];const server=await startServer();
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'functional-reading-'));
const port=9700+Math.floor(Math.random()*200);
const chrome=spawn(findChrome(),['--headless=new','--no-sandbox','--disable-gpu',`--remote-debugging-port=${port}`,`--user-data-dir=${profile}`,'about:blank'],{stdio:'ignore',windowsHide:true});
let c;const scenes=[];
const settle=()=>new Promise(r=>setTimeout(r,350));
const measure=String.raw`(selector)=>{
 const host=document.querySelector(selector);if(!host)throw Error('missing '+selector);
 const elementScale=e=>{let box=e;while(box&&!box.offsetWidth)box=box.parentElement;return box?box.getBoundingClientRect().width/box.offsetWidth:1;};
 const rows=[],overflow=[],controls=[];
 const tree=document.createTreeWalker(host,NodeFilter.SHOW_TEXT);
 while(tree.nextNode()){
  const n=tree.currentNode,e=n.parentElement,text=n.textContent.trim();
  if(!text||!e||e.closest('script,style,[aria-hidden="true"],.nav-sr-only,.inventory-title-plate-kicker'))continue;
  const s=getComputedStyle(e),r=e.getBoundingClientRect();
  if(!r.width||!r.height||s.visibility==='hidden'||s.display==='none')continue;
  if(/^[＋+×‹›◀▶▼▲▾◇◆…·—→←？]+$/.test(text))continue;
  const after=getComputedStyle(e,'::after');
  const replaced=parseFloat(s.fontSize)===0&&after.content&&after.content!=='none';
  const font=parseFloat(replaced?after.fontSize:s.fontSize)*elementScale(e);
  const button=!!e.closest('button,[role="tab"],[role="button"],.character-showcase-choice');
  const primary=button&&e.matches('button,#creationSubmitLabel,.creation-next>span,.creation-back>span,.element-option .element-name')&&!e.closest('.home-test-tools');
  rows.push({text:text.slice(0,90),font,button,primary,selector:e.id?'#'+e.id:e.tagName.toLowerCase()+'.'+String(e.className).trim().replace(/\s+/g,'.'),parent:e.parentElement.id||e.parentElement.className});
 }
 for(const e of host.querySelectorAll('button,[role="tab"],[role="button"],.custom-dropdown-label,.custom-dropdown-item')){
  const dropdown=e.closest('.custom-dropdown-list');if(dropdown&&Number(getComputedStyle(dropdown).opacity)===0)continue;
  const s=getComputedStyle(e),r=e.getBoundingClientRect();if(!r.width||!r.height||s.visibility==='hidden'||!e.textContent.trim())continue;
  const walker=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),bounds=[];
  while(walker.nextNode()){const n=walker.currentNode;if(!n.textContent.trim()||n.parentElement.closest('[aria-hidden="true"]'))continue;const range=document.createRange();range.selectNodeContents(n);bounds.push(range.getBoundingClientRect());}
  const t={left:Math.min(...bounds.map(b=>b.left)),right:Math.max(...bounds.map(b=>b.right)),top:Math.min(...bounds.map(b=>b.top)),bottom:Math.max(...bounds.map(b=>b.bottom))};
  const clamped=Array.from(e.querySelectorAll('*')).some(n=>parseInt(getComputedStyle(n).webkitLineClamp)>0);
  const labelControl=e.matches('button,[role="tab"],.custom-dropdown-label,.custom-dropdown-item')&&!clamped;
  controls.push({label:(e.textContent||e.getAttribute('aria-label')||'').trim().slice(0,60),width:r.width,height:r.height,overflow:labelControl&&(t.left<r.left-1||t.right>r.right+1||t.top<r.top-1||t.bottom>r.bottom+1)});
 }
 for(const e of host.querySelectorAll('h1,h2,h3,.item-modal-name,.home-feature-modal-title,[role="tablist"]')){
  const r=e.getBoundingClientRect();if(!r.width||!r.height)continue;
  if(e.scrollWidth>e.clientWidth+1)overflow.push({text:e.textContent.trim().slice(0,60),width:r.width,scroll:e.scrollWidth,client:e.clientWidth});
 }
 return {rows,controls,overflow};
}`;
try{
 const target=(await waitJson(`http://127.0.0.1:${port}/json/list`)).find(t=>t.type==='page');
 c=new Cdp(target.webSocketDebuggerUrl);await c.send('Page.enable');await c.send('Runtime.enable');
 await c.send('Emulation.setDeviceMetricsOverride',{width:viewport[0],height:viewport[1],deviceScaleFactor:1,mobile:viewport[0]<800});
 await c.send('Page.navigate',{url:server.url});await c.eval(prepare);
 await c.eval("(async()=>{await FourSymbolsFeatures.ensure('relic','functional-reading');await FourSymbolsFeatures.ensure('gameplay-core','functional-reading');})()");
 await c.eval("(()=>{const armor=v17346GenerateEquipment(()=>.2,{slot:'armor',classType:'warrior',rarity:'orange',uid:'reading-equipped-armor'});const bagArmor=v17346GenerateEquipment(()=>.2,{slot:'armor',classType:'warrior',rarity:'orange',uid:'reading-bag-armor'});inventoryItems.push(bagArmor,{...getPotionDefinition('hpPotion10'),count:30});characterEquipment.fire.armor=armor;rebuildInventorySlots();renderInventory();})()");
 const capture=async(name,selector='#homeFeatureModal')=>{
  await settle();const data=await c.eval(`(${measure})(${JSON.stringify(selector)})`);
  checks.push({captureAttempt:{name,controls:data.controls,overflow:data.overflow}});
  assert.ok(data.rows.length||data.controls.length,name+': empty UI coverage');if(selector==='#homeFeatureModal')for(const q of data.controls)assert.ok(q.height>=44,name+' control below44 '+JSON.stringify(q));
  scenes.push({name,...data});fs.writeFileSync(path.join(out,'all-text.json'),JSON.stringify(scenes,null,2));
  const image=await c.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(out,name+'.png'),Buffer.from(image.data,'base64'));
  fs.writeFileSync(path.join(out,'partial-report.json'),JSON.stringify({complete:false,head:sourceHead,dirty:sourceDirty,viewport,sourcesBefore,sourcesAfter:hash(),sourceUnchanged:JSON.stringify(sourcesBefore)===JSON.stringify(hash()),touches,checks,scenes:scenes.map(s=>s.name),scope:'Segment24B partial evidence only; no completion claim'},null,2));
  console.log(name+': '+data.rows.length+' text nodes, '+data.rows.filter(x=>x.font<12.9).length+' below minimum');
 };
 const tap=async selector=>{
  const point=await c.eval(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e)return null;const r=e.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,hit=document.elementFromPoint(x,y);return {x,y,width:r.width,height:r.height,hit:hit===e||e.contains(hit),label:e.textContent.trim()};})()`);
  touches.push({selector,...point});assert.ok(point&&point.height>=44,'actual target below44 '+selector+' '+JSON.stringify(point));assert.ok(point?.hit,'real touch is blocked: '+selector+' '+JSON.stringify(point));
  await c.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:point.x,y:point.y}]});
  await c.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await settle();
 };

 
 const end=async(root)=>{const sel=await c.eval('(()=>{const r=document.querySelector('+JSON.stringify(root)+'),e=[r,...r.querySelectorAll("*")].filter(e=>{const q=e.getBoundingClientRect();return q.height>50&&q.width>50&&e.scrollHeight>e.clientHeight+2&&/auto|scroll/.test(getComputedStyle(e).overflowY)}).sort((a,b)=>b.clientHeight-a.clientHeight)[0];if(!e)return null;e.dataset.qaScroll="active";return "[data-qa-scroll=active]"})()');if(!sel){touches.push({root,scroll:'not-needed'});return;}for(let n=0;n<20;n++){const p=await c.eval('(()=>{const e=document.querySelector('+JSON.stringify(sel)+'),r=e.getBoundingClientRect();return {x:r.x+r.width*.75,y:r.bottom-25,to:r.top+25,top:e.scrollTop,client:e.clientHeight,height:e.scrollHeight}})()');if(p.top+p.client>=p.height-2){touches.push({root,scroll:sel,...p});await c.eval('document.querySelector('+JSON.stringify(sel)+').removeAttribute("data-qa-scroll")');return;}if(viewport[0]>=800)await c.send('Input.dispatchMouseEvent',{type:'mouseWheel',x:p.x,y:(p.y+p.to)/2,deltaX:0,deltaY:550});else{await c.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:p.x,y:p.y}]});for(let i=1;i<=14;i++){await c.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:p.x,y:p.y+(p.to-p.y)*i/14}]});await new Promise(r=>setTimeout(r,20));}await c.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});}await settle();}throw Error('end not reached '+root);};
 const contexts=['Three actual character choices x status/skill/expPool TAB; locked/uncreated and eligible creation entry/cancel only'];
 const reveal=async(sel)=>{await c.eval('document.querySelector('+JSON.stringify(sel)+').scrollIntoView({block:"center"})');await settle();};const back=async()=>{await tap('#homeFeatureModal .home-feature-close-btn:not(#statusHelpButton)');};
 await c.eval("closeHomeFeature();showPage('home');window.__qa24BOriginal={player:structuredClone(player),player2,player3,loadouts:structuredClone(characterSkillLoadouts),statusCharacterIndex,inventoryCharacterIndex,currentSkillCharacter};window.__qa24BSaveOriginal=saveGame;window.__qa24BSaveCalls=[];saveGame=function(...args){window.__qa24BSaveCalls.push({at:performance.now(),stage:window.__qa24BStage});return window.__qa24BSaveOriginal.apply(this,args)}");
 const phase=async(stage)=>{checks.push({phase:stage,state:await c.eval('({stage:window.__qa24BStage='+JSON.stringify(stage)+',characters:getExistingPartyIndexes().map(i=>{const x=getPartyCharacterByIndex(i);return{i,id:x.id,level:x.level,expNext:x.expNext,hp:x.hp,sp:x.sp}}),saveCalls:window.__qa24BSaveCalls.length})')});};
 await phase('before-local-fixture');const fixture=await c.eval("(()=>{const names=['角色名稱長文測試甲乙丙丁戊己庚辛','甲乙丙丁戊己庚辛壬癸子丑寅卯辰巳','子丑寅卯辰巳午未申酉戌亥甲乙丙丁'];const seed=structuredClone(player);Object.assign(player,{id:names[0],element:'fire',level:70});player2={...structuredClone(seed),id:names[1],element:'water',level:60};player3={...structuredClone(seed),id:names[2],element:'wind',level:50};for(const c of [player,player2,player3]){c.expNext=window.v133GetExpNextForLevel(c.level);}window.__qa24BStage='fixture-before-formal-normalization';return{names,levels:[70,60,50],isolatedOnly:true,notCharacterCreation:true}})()");for(const n of fixture.names)assert.equal([...n].length,16);checks.push({fixture});await c.eval("window.__qa24BStage='fixture-formal-exp-render';renderExpDistributeList();");await phase('after-fixture-formal-exp-render');await phase('after-fixture-before-entry');await tap('[data-city-entry="0"]');await phase('after-formal-entry-normalization');
 const state=async()=>c.eval("(()=>{const content=document.getElementById('characterTabContent'),body=content.getBoundingClientRect(),h=document.getElementById('homeFeatureModalTitle').getBoundingClientRect();return{statusCharacterIndex,inventoryCharacterIndex,currentSkillCharacter,expectedSkillKey:getPartyCharacterKey(statusCharacterIndex),tab:homeFeatureModal.dataset.characterTab,content:{rect:body.toJSON(),top:content.scrollTop,height:content.scrollHeight,client:content.clientHeight,overflow:getComputedStyle(content).overflowY},title:h.toJSON(),choices:[...document.querySelectorAll('.character-showcase-choice')].map((e,i)=>{const n=e.querySelector('.character-showcase-name'),l=e.querySelector('[id^=characterAvatarLevel]'),r=document.createRange();r.selectNodeContents(n);return{i,selected:e.classList.contains('is-current-character'),name:n.innerText,nameBox:n.getBoundingClientRect().toJSON(),nameInk:r.getBoundingClientRect().toJSON(),level:l.innerText,levelRect:l.getBoundingClientRect().toJSON(),rect:e.getBoundingClientRect().toJSON()}}),tabs:[...document.querySelectorAll('.character-tab-row button')].map(e=>({id:e.id,text:e.innerText,rect:e.getBoundingClientRect().toJSON()}))}})()");
 const check=(q,index,tab)=>{assert.equal(q.statusCharacterIndex,index);assert.equal(q.inventoryCharacterIndex,index);assert.equal(q.currentSkillCharacter,q.expectedSkillKey);assert.equal(q.tab,tab);assert.ok(q.content.rect.height>=100,'content viewport too small '+q.content.rect.height);assert.equal(q.choices.length,3);for(const x of q.choices){assert.equal(x.name,fixture.names[x.i]);assert.equal(x.level,'Lv.'+fixture.levels[x.i]);assert.equal(x.selected,x.i===index);assert.ok(x.nameInk.left>=x.nameBox.left-1&&x.nameInk.right<=x.nameBox.right+1&&x.nameInk.top>=x.nameBox.top-1&&x.nameInk.bottom<=x.nameBox.bottom+1,'name glyph clipped');assert.ok(x.nameInk.bottom<=x.levelRect.top+1,'name overlaps level');assert.ok(x.nameInk.top>=q.title.bottom-1,'name overlaps title');}for(const t of q.tabs){assert.ok(t.rect.height>=44);assert.ok(t.rect.bottom<=q.content.rect.top+1,'TAB overlaps pane');}};
 const expState=async()=>c.eval("(()=>{const ink=e=>{if(!e)return null;const r=document.createRange();r.selectNodeContents(e);return r.getBoundingClientRect().toJSON()},box=e=>e?.getBoundingClientRect().toJSON()||null;return{rows:[...document.querySelectorAll('#expDistributeList .v131-exp-row')].map((e,i)=>{const n=e.querySelector('.v131-exp-name'),l=e.querySelector('.v131-exp-level'),m=e.querySelector('.v173-exp-row-meta'),b=m?.querySelector('b');return{i,name:n?.innerText,level:l?.innerText,rect:box(e),nameBox:box(n),nameInk:ink(n),meta:{text:m?.innerText,rect:box(m),ink:ink(m)},badge:{text:b?.innerText,rect:box(b),ink:ink(b)}}}),footer:box(document.querySelector('#expDistributeList .v131-exp-actions')),owner:box(document.getElementById('characterTabContent'))}})()");
 const checkExp=async(stage,index,atEnd=false)=>{const q=await expState();checks.push({phase:'canonical-exp-rows',stage,index,...q});assert.equal(q.rows.length,3,'EXP must reflect all three canonical characters');for(const r of q.rows){assert.equal(r.name,fixture.names[r.i]);assert.equal(r.level,'Lv.'+fixture.levels[r.i]);assert.ok(r.nameInk.left>=r.nameBox.left-1&&r.nameInk.right<=r.nameBox.right+1,'EXP full name ink clipped');assert.ok(r.meta.text,'EXP canonical metadata absent');for(const b of [r.meta,r.badge])if(b.rect&&b.ink){assert.ok(b.ink.left>=r.rect.left-1&&b.ink.right<=r.rect.right+1,'EXP meta/badge escapes row');}}if(atEnd){const last=q.rows[2];assert.ok(last.rect.bottom<=q.owner.bottom+1,'Third EXP card bottom unreachable');assert.ok(q.footer&&q.footer.top>=last.rect.bottom-1,'EXP footer covers last card');assert.ok(q.footer.bottom<=q.owner.bottom+1,'EXP footer unreachable');}return q;};
 const paneTop=async()=>{const sel='#characterTabContent';for(let n=0;n<30;n++){const p=await c.eval('(()=>{const e=document.querySelector('+JSON.stringify(sel)+'),r=e.getBoundingClientRect();return{top:e.scrollTop,x:r.right-30,y:r.top+30,to:r.bottom-30}})()');if(p.top<=1){touches.push({kind:'pane-real-top',owner:sel,...p});return;}if(viewport[0]>=800)await c.send('Input.dispatchMouseEvent',{type:'mouseWheel',x:p.x,y:p.y,deltaX:0,deltaY:-400});else{await c.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:p.x,y:p.y}]});for(let j=1;j<=12;j++){await c.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:p.x,y:p.y+(p.to-p.y)*j/12}]});await new Promise(r=>setTimeout(r,20));}await c.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});}await settle();}throw Error('pane top not reached');};
 for(let index=0;index<3;index++){const choice='.character-showcase-choice[onclick="selectCharacterForTabs('+index+');"]';await reveal(choice);await tap(choice);for(const [tab,id] of [['status','Status'],['skill','Skill'],['expPool','ExpPool']]){await reveal('#characterTabBtn'+id);await tap('#characterTabBtn'+id);await paneTop();let q=await state();check(q,index,tab);checks.push({selectedBinding:q});if(tab==='expPool')await checkExp('top',index);await capture('character-'+index+'-'+tab+'-top','#homeFeatureModal');await end('#characterTabContent');q=await state();check(q,index,tab);checks.push({selectedBindingEnd:q});if(tab==='expPool')await checkExp('end',index,true);await capture('character-'+index+'-'+tab+'-end','#homeFeatureModal');}await phase('selected-'+index+'-read-only');}await back();await tap('[data-city-entry="0"]');await capture('three-character-reopen','#homeFeatureModal');await back();
 for(const mode of ['locked','second-eligible','third-eligible']){await c.eval("(()=>{const seed=structuredClone(__qa24BOriginal.player);Object.assign(player,{id:'QA 火',level:"+(mode==='locked'?1:70)+"});player2="+(mode==='third-eligible'?"{...seed,id:'QA 水',level:60}":"null")+";player3=null;window.__qa24BStage="+JSON.stringify(mode)+";})()");await tap('[data-city-entry="0"]');await capture('slot-'+mode,'#homeFeatureModal');const slot=mode==='third-eligible'?3:2,selector='.character-showcase-row > div:nth-child('+slot+')';const before=await c.eval('({player2:!!player2,player3:!!player3,creation:document.getElementById("creationPage")?.style.display})');if(mode==='locked'){await reveal(selector);await tap(selector);assert.equal(await c.eval('!!player2||!!player3'),false);checks.push({lockedNoCreate:true,before});await back();}else{const button='[onclick="closeHomeFeature();openCharacterCreation('+slot+');"]';await reveal(button);await tap(button);await capture('creation-'+slot+'-entry-no-submit','#creationPage');const cancel='#creationAdditionalStepOneActions [onclick="cancelAdditionalCharacterCreation()"]';await reveal(cancel);await tap(cancel);assert.equal(await c.eval(slot===2?'!!player2':'!!player3'),false);checks.push({eligibleEntryCancelled:slot,noCharacterCreated:true});await c.eval("closeHomeFeature();showPage('home')");}}
 await phase('completed-read-and-cancel-only');checks.push({delegatedSaveCalls:await c.eval('window.__qa24BSaveCalls'),scope:'Original select/render/normalize/save sideeffects retained; no confirmation, learning, equip or create submit.'});await c.eval('saveGame=window.__qa24BSaveOriginal');

  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({complete:true,sourcesBefore,sourcesAfter:hash(),sourceUnchanged:JSON.stringify(sourcesBefore)===JSON.stringify(hash()),loaded:await c.eval("performance.getEntriesByType('resource').map(e=>new URL(e.name).pathname).filter(p=>p.endsWith('.css')||p.endsWith('.js'))"),touches,checks,head:sourceHead,dirty:sourceDirty,viewport,contexts,scenes:scenes.map(s=>({name:s.name,small:s.rows.filter(x=>x.font<12.9),overflow:s.overflow,clipped:s.controls.filter(x=>x.overflow)})),scope:"Segment24B three actual choices x status/skill/expPool, legal16 names, glyph/Lv/TAB/pane viewport and true first/end/return. Canonical isolated character fixtures and formal normalization tracked separately; original save calls delegated. Locked and eligible uncreated entry/cancel only, no allocation confirm/learn/equip/create/transaction. Hardware keyboard and full alternative business states not approved."},null,2));
 }catch(error){try{if(c){const shot=await c.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(out,'failure.png'),Buffer.from(shot.data,'base64'));}}catch{};fs.writeFileSync(path.join(out,'failure-report.json'),JSON.stringify({complete:false,error:String(error),head:sourceHead,dirty:sourceDirty,viewport,sourcesBefore,sourcesAfter:hash(),touches,checks,scenes:scenes.map(s=>s.name)},null,2));throw error;}finally{try{if(c)await c.eval('if(window.__qa24BSaveOriginal)saveGame=window.__qa24BSaveOriginal;if(window.__qa24BOriginal){const o=__qa24BOriginal;Object.assign(player,o.player);player2=o.player2;player3=o.player3;for(const k of Object.keys(characterSkillLoadouts))delete characterSkillLoadouts[k];Object.assign(characterSkillLoadouts,o.loadouts);statusCharacterIndex=o.statusCharacterIndex;inventoryCharacterIndex=o.inventoryCharacterIndex;currentSkillCharacter=o.currentSkillCharacter;}');}catch{};c?.close();chrome.kill();await new Promise(r=>server.server.close(r));}








