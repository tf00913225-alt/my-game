import fs from 'node:fs';
import {collect as collectHome,localRosterFixture,noticeFixture,plan as homePlan} from './ui-skill-standard/segment24-home-preparation.mjs';
import os from 'node:os';
import crypto from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
import {ROOT,startServer,waitJson,Cdp,findChrome} from '../.github/scripts/runtime-browser-qa-support.mjs';

// Use the same isolated account and the real production loader as skill QA.
const skillQa=fs.readFileSync(path.join(ROOT,'.github/scripts/run-skill-progression-browser-qa.mjs'),'utf8');
const prepare=skillQa.match(/const PREPARE_RUNTIME=`([\s\S]*?)`;/)[1];
assert.equal(process.env.RUN_HOME_TOUCH_DELTA,'1','Prepared only: root review required');
const viewport=JSON.parse(process.env.UI_READING_VIEWPORT||'[393,873]');
const sourceHead=process.env.GITHUB_SHA||execFileSync('git',['rev-parse','HEAD'],{cwd:ROOT,encoding:'utf8'}).trim();
const sourceDirty=!!execFileSync('git',['status','--porcelain'],{cwd:ROOT,encoding:'utf8'}).trim();
const out=path.join(ROOT,'artifacts/ui-skill-standard/segment26-home-touch-'+sourceHead.slice(0,8)+'/prepared4',viewport.join('x'));if(fs.existsSync(out))throw Error('Output exists');
fs.mkdirSync(out,{recursive:true});
const hash=()=>Object.fromEntries(['index.html','asset-manifest.json','js/16-stage-v54-main-city-runtime.js','js/relic-summary-catalog.js','js/49-v169-element-box-settings.js','js/25-v131-fix-batch.js','js/00-main.js','css/48-v169-element-box-settings.css',...fs.readdirSync('build').filter(x=>/\.(css|js)$/.test(x)).map(x=>'build/'+x)].map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')]));const sourcesBefore=hash(),touches=[],checks=[];const server=await startServer();
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'functional-reading-'));
const port=9700+Math.floor(Math.random()*200);
const chrome=spawn(findChrome(),['--headless=new','--no-sandbox','--disable-gpu',`--remote-debugging-port=${port}`,`--user-data-dir=${profile}`,'about:blank'],{stdio:'ignore',windowsHide:true});
let c;const scenes=[];
const settle=()=>new Promise(r=>setTimeout(r,350));
const measure=String.raw`(selector)=>{
 const host=document.querySelector(selector);if(!host)throw Error('missing '+selector);
 const elementScale=e=>{let box=e;while(box&&!box.offsetWidth)box=box.parentElement;return box?box.getBoundingClientRect().width/box.offsetWidth:1;};
 const rows=[],overflow=[],controls=[];
 const tree=document.createTreeWalker(host,NodeFilter.SHOW_TEXT);
 while(tree.nextNode()){
  const n=tree.currentNode,e=n.parentElement,text=n.textContent.trim();
  if(!text||!e||e.closest('script,style,[aria-hidden="true"],.nav-sr-only,.inventory-title-plate-kicker'))continue;
  const s=getComputedStyle(e),r=e.getBoundingClientRect();
  if(!r.width||!r.height||s.visibility==='hidden'||s.display==='none')continue;
  if(/^[＋+×‹›◀▶▼▲▾◇◆…·—→←？]+$/.test(text))continue;
  const after=getComputedStyle(e,'::after');
  const replaced=parseFloat(s.fontSize)===0&&after.content&&after.content!=='none';
  const font=parseFloat(replaced?after.fontSize:s.fontSize)*elementScale(e);
  const button=!!e.closest('button,[role="tab"],[role="button"],.custom-dropdown-label,.custom-dropdown-item');
  const primary=button&&e.matches('button,#creationSubmitLabel,.creation-next>span,.creation-back>span,.element-option .element-name')&&!e.closest('.home-test-tools');
  rows.push({text:text.slice(0,90),font,button,primary,selector:e.id?'#'+e.id:e.tagName.toLowerCase()+'.'+String(e.className).trim().replace(/\s+/g,'.'),parent:e.parentElement.id||e.parentElement.className});
 }
 for(const e of host.querySelectorAll('button,[role="tab"],[role="button"],.custom-dropdown-label,.custom-dropdown-item')){
  const dropdown=e.closest('.custom-dropdown-list');if(dropdown&&Number(getComputedStyle(dropdown).opacity)===0)continue;
  const s=getComputedStyle(e),r=e.getBoundingClientRect();if(!r.width||!r.height||s.visibility==='hidden'||!e.textContent.trim())continue;
  const walker=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),bounds=[];
  while(walker.nextNode()){const n=walker.currentNode;if(!n.textContent.trim()||n.parentElement.closest('[aria-hidden="true"]'))continue;const range=document.createRange();range.selectNodeContents(n);bounds.push(range.getBoundingClientRect());}
  const t={left:Math.min(...bounds.map(b=>b.left)),right:Math.max(...bounds.map(b=>b.right)),top:Math.min(...bounds.map(b=>b.top)),bottom:Math.max(...bounds.map(b=>b.bottom))};
  const clamped=Array.from(e.querySelectorAll('*')).some(n=>parseInt(getComputedStyle(n).webkitLineClamp)>0);
  const labelControl=e.matches('button,[role="tab"],.custom-dropdown-label,.custom-dropdown-item')&&!clamped;
  controls.push({label:(e.textContent||e.getAttribute('aria-label')||'').trim().slice(0,60),width:r.width,height:r.height,overflow:labelControl&&(t.left<r.left-1||t.right>r.right+1||t.top<r.top-1||t.bottom>r.bottom+1)});
 }
 for(const e of host.querySelectorAll('h1,h2,h3,.item-modal-name,.home-feature-modal-title,[role="tablist"]')){
  const r=e.getBoundingClientRect();if(!r.width||!r.height)continue;
  if(e.scrollWidth>e.clientWidth+1)overflow.push({text:e.textContent.trim().slice(0,60),width:r.width,scroll:e.scrollWidth,client:e.clientWidth});
 }
 return {rows,controls,overflow};
}`;
try{
 const target=(await waitJson(`http://127.0.0.1:${port}/json/list`)).find(t=>t.type==='page');
 c=new Cdp(target.webSocketDebuggerUrl);await c.send('Page.enable');await c.send('Runtime.enable');
 await c.send('Emulation.setDeviceMetricsOverride',{width:viewport[0],height:viewport[1],deviceScaleFactor:1,mobile:viewport[0]<800});
 await c.send('Page.navigate',{url:server.url});await c.eval(prepare);
 await c.eval("(async()=>{await FourSymbolsFeatures.ensure('relic','functional-reading');await FourSymbolsFeatures.ensure('gameplay-core','functional-reading');})()");
 await c.eval("(()=>{const armor=v17346GenerateEquipment(()=>.2,{slot:'armor',classType:'warrior',rarity:'orange',uid:'reading-equipped-armor'});const bagArmor=v17346GenerateEquipment(()=>.2,{slot:'armor',classType:'warrior',rarity:'orange',uid:'reading-bag-armor'});inventoryItems.push(bagArmor,{...getPotionDefinition('hpPotion10'),count:30});characterEquipment.fire.armor=armor;rebuildInventorySlots();renderInventory();})()");
 const capture=async(name,selector='#homeFeatureModal')=>{
  await settle();const data=await c.eval(`(${measure})(${JSON.stringify(selector)})`);
  checks.push({captureAttempt:{name,controls:data.controls,overflow:data.overflow}});
  assert.ok(data.rows.length||data.controls.length,name+': empty UI coverage');if(selector==='#homeFeatureModal')for(const q of data.controls)assert.ok(q.height>=44,name+' control below44 '+JSON.stringify(q));
  scenes.push({name,...data});fs.writeFileSync(path.join(out,'all-text.json'),JSON.stringify(scenes,null,2));
  const image=await c.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(out,name+'.png'),Buffer.from(image.data,'base64'));
  fs.writeFileSync(path.join(out,'partial-report.json'),JSON.stringify({complete:false,head:sourceHead,dirty:sourceDirty,viewport,sourcesBefore,sourcesAfter:hash(),sourceUnchanged:JSON.stringify(sourcesBefore)===JSON.stringify(hash()),touches,checks,scenes:scenes.map(s=>s.name),scope:'Segment24 partial evidence only; no completion claim'},null,2));
  console.log(name+': '+data.rows.length+' text nodes, '+data.rows.filter(x=>x.font<12.9).length+' below minimum');
 };
 const tap=async selector=>{
  const point=await c.eval(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e)return null;const r=e.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,hit=document.elementFromPoint(x,y);return {x,y,width:r.width,height:r.height,hit:hit===e||e.contains(hit),label:e.textContent.trim()};})()`);
  touches.push({selector,...point});assert.ok(point&&point.height>=44,'actual target below44 '+selector+' '+JSON.stringify(point));assert.ok(point?.hit,'real touch is blocked: '+selector+' '+JSON.stringify(point));
  if(viewport[0]>=800){await c.send('Input.dispatchMouseEvent',{type:'mousePressed',x:point.x,y:point.y,button:'left',clickCount:1});await c.send('Input.dispatchMouseEvent',{type:'mouseReleased',x:point.x,y:point.y,button:'left',clickCount:1});}else{await c.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:point.x,y:point.y}]});await c.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});}await settle();
 };

 
 const end=async(root)=>{const sel=await c.eval('(()=>{const r=document.querySelector('+JSON.stringify(root)+'),e=[r,...r.querySelectorAll("*")].filter(e=>{const q=e.getBoundingClientRect();return q.height>50&&q.width>50&&e.scrollHeight>e.clientHeight+2&&/auto|scroll/.test(getComputedStyle(e).overflowY)}).sort((a,b)=>b.clientHeight-a.clientHeight)[0];if(!e)return null;e.dataset.qaScroll="active";return "[data-qa-scroll=active]"})()');if(!sel){touches.push({root,scroll:'not-needed'});return;}for(let n=0;n<20;n++){const p=await c.eval('(()=>{const e=document.querySelector('+JSON.stringify(sel)+'),r=e.getBoundingClientRect();return {x:r.x+r.width*.75,y:r.bottom-25,to:r.top+25,top:e.scrollTop,client:e.clientHeight,height:e.scrollHeight}})()');if(p.top+p.client>=p.height-2){touches.push({root,scroll:sel,...p});await c.eval('document.querySelector('+JSON.stringify(sel)+').removeAttribute("data-qa-scroll")');return;}if(viewport[0]>=800)await c.send('Input.dispatchMouseEvent',{type:'mouseWheel',x:p.x,y:(p.y+p.to)/2,deltaX:0,deltaY:550});else{await c.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:p.x,y:p.y}]});for(let i=1;i<=14;i++){await c.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:p.x,y:p.y+(p.to-p.y)*i/14}]});await new Promise(r=>setTimeout(r,20));}await c.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});}await settle();}throw Error('end not reached '+root);};
 const contexts=['Home DEV measurement + footer entry/return only; no formation/summary acceptance'];
 const reveal=async(sel)=>{await c.eval('document.querySelector('+JSON.stringify(sel)+').scrollIntoView({block:"center"})');await settle();};const back=async()=>{await tap('#homeFeatureModal .home-feature-close-btn:not(#statusHelpButton)');};
 await c.eval("closeHomeFeature();showPage('home')");checks.push({homePlan});
 const wait=async(sel)=>c.eval('(async()=>{for(let i=0;i<100;i++){if(document.querySelector('+JSON.stringify(sel)+'))return;await new Promise(r=>setTimeout(r,100));}throw Error("missing formal UI")})()');
 const homePosition=()=>c.eval("(()=>{const h=document.getElementById('homePage');return{active:h.classList.contains('active'),top:h.scrollTop,client:h.clientHeight,height:h.scrollHeight,overflow:getComputedStyle(h).overflowY,rect:h.getBoundingClientRect().toJSON(),ancestors:(()=>{const a=[];for(let e=h.parentElement;e;e=e.parentElement)a.push({id:e.id,cls:String(e.className),top:e.scrollTop,left:e.scrollLeft});return a})()}})()");
 const homeScroll=async(direction)=>{const initial=await homePosition();assert.match(initial.overflow,/auto|scroll/,'home must own scroll');for(let n=0;n<80;n++){const q=await homePosition(),done=direction==='top'?q.top<=1:q.top+q.client>=q.height-2;if(done){assert.deepEqual(q.ancestors,initial.ancestors,'outer owner moved');touches.push({kind:'home-scroll-end',owner:'#homePage',direction,steps:n,...q});return q;}const r=q.rect,x=r.left+r.width*.8,y=direction==='top'?r.top+35:r.bottom-35,to=direction==='top'?r.bottom-35:r.top+35;if(viewport[0]>=800)await c.send('Input.dispatchMouseEvent',{type:'mouseWheel',x,y:(r.top+r.bottom)/2,deltaX:0,deltaY:direction==='top'?-420:420});else{await c.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});for(let i=1;i<=14;i++){await c.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x,y:y+(to-y)*i/14}]});await new Promise(r=>setTimeout(r,20));}await c.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});}await settle();touches.push({kind:'home-true-scroll',owner:'#homePage',direction,step:n});}throw Error('bounded home scroll did not reach '+direction);};
 const homeTop=()=>homeScroll('top'),homeEnd=()=>homeScroll('end');
 const compact=value=>{const whole=Math.max(0,Math.floor(Number(value)||0));if(whole>=1e8){const v=whole/1e8;return v.toFixed(v>=10?1:2).replace(/\.?0+$/g,'')+'億';}if(whole>=1e4)return Math.floor(whole/1e4)+'萬';return whole.toLocaleString('zh-TW');};
 const verifyResources=q=>{assert.equal(q.resourceApiExactRestored,true);for(const r of q.resources){const value=r.id==='homeHudGoldValue'?q.resourceSample.gold:q.resourceSample.exp,whole=Math.max(0,Math.floor(Number(value)||0)),full=whole.toLocaleString('zh-TW');assert.equal(r.title,full);assert.equal(r.aria,full);assert.equal(r.text,compact(value));assert.ok(r.ink.left>=r.rect.left-1&&r.ink.right<=r.rect.right+1&&r.ink.top>=r.rect.top-1&&r.ink.bottom<=r.rect.bottom+1,'resource ink clipped');}};
 const anchorSnapshot=async(selector)=>({position:await homePosition(),anchor:await c.eval('(()=>{const r=document.querySelector('+JSON.stringify(selector)+').getBoundingClientRect();return{selector:'+JSON.stringify(selector)+',rect:r.toJSON()}})()')});
 const verifyReturn=async(before,name)=>{const after=await anchorSnapshot(before.anchor.selector);assert.equal(after.position.active,true);assert.ok(Math.abs(after.position.top-before.position.top)<=1,name+' home scroll changed');assert.deepEqual(after.position.ancestors,before.position.ancestors,name+' outer scroll changed');assert.ok(Math.abs(after.anchor.rect.top-before.anchor.rect.top)<=1,name+' anchor changed');checks.push({returnPreserved:name,before,after});await capture(name+'-home-return','#homePage');};
 const controlGeometry=async(kind)=>{const result=await c.eval("(()=>{const nodes=[...document.querySelectorAll('#homePage "+(kind==='dev'?'.home-test-button':'.home-card-tertiary')+"')];return nodes.map(e=>{const r=e.getBoundingClientRect(),label=e.querySelector('.home-card-label')||e,s=getComputedStyle(label),scale=label.getBoundingClientRect().width/label.offsetWidth,x=r.left+r.width/2,y=r.top+r.height/2,h=document.elementFromPoint(x,y);return{text:e.textContent.trim(),height:r.height,width:r.width,font:parseFloat(s.fontSize)*scale,rect:r.toJSON(),hit:h===e||e.contains(h)};});})()");assert.equal(result.length,kind==='dev'?2:4);for(const q of result){assert.ok(q.height>=43.9,'Target below44 '+JSON.stringify(q));assert.ok(q.font>=14.9,'Font below15 '+JSON.stringify(q));assert.ok(q.hit,'Target covered '+JSON.stringify(q));}checks.push({kind:kind+'-geometry-only-no-dev-click',controls:result});return result;};
 for(const count of [1,3]){checks.push({fixture:await localRosterFixture(c,count)});await homeTop();await controlGeometry('dev');await capture('home-'+count+'-longname-top','#homePage');await homeEnd();await controlGeometry('footer');await capture('home-'+count+'-footer-end','#homePage');}
 for(const present of [false,true]){checks.push({noticeFixture:await noticeFixture(c,present)});await homeTop();const q=await collectHome(c);assert.equal(q.notification.exists,present);checks.push({notification:q.notification});await capture('notice-'+present+'-top','#homePage');await homeEnd();await controlGeometry('footer');await capture('notice-'+present+'-end','#homePage');}
 for(const feature of ['achievement','announcement','offlineExp','system']){await homeEnd();const sel='.home-card-tertiary[onclick="openHomeFeature(\''+feature+'\')"]',before=await anchorSnapshot(sel);await tap(sel);await wait('#homeFeatureModal.show');await capture(feature+'-entry','#homeFeatureModal');await back();await verifyReturn(before,feature);}
 await homeEnd();const safety=await c.eval("(()=>{const h=document.getElementById('homePage').getBoundingClientRect(),e=document.getElementById('inventoryNav'),r=e.getBoundingClientRect(),hit=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2),f=[...document.querySelectorAll('#homePage .home-card-tertiary')].map(e=>e.getBoundingClientRect());return{home:h.toJSON(),nav:r.toJSON(),navHit:!!hit?.closest('#inventoryNav'),footerSafe:f.every(x=>x.bottom<=h.bottom+1&&x.bottom<=r.top+1)};})()");checks.push({navSafety:safety});assert.ok(safety.navHit&&safety.footerSafe,'Footer/nav overlap');await capture('final-home-footer-nav','#homePage');
 const sourcesAfter=hash();assert.deepEqual(sourcesAfter,sourcesBefore);assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:ROOT,encoding:'utf8'}).trim(),sourceHead);fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({head:sourceHead,dirty:sourceDirty,viewport,complete:true,sourcesBefore,sourcesAfter,sourceUnchanged:true,touches,checks,scenes,scope:'Home DEV geometry only (never click resources), 1/3 canonical long names, notices absent/present, four footer true entry/header return/anchor and nav safe region only. No formation/summary/equip/claim/update/transactions or whole-page content acceptance; original background sideeffects retained.'},null,2));
 }catch(error){fs.writeFileSync(path.join(out,'failure-report.json'),JSON.stringify({head:sourceHead,complete:false,error:String(error.message||error).split('\n')[0],touches,checks,scenes:scenes.map(x=>x.name)},null,2));if(c)try{fs.writeFileSync(path.join(out,'failure.png'),Buffer.from((await c.send('Page.captureScreenshot',{format:'png'})).data,'base64'));}catch{}throw error;}finally{c?.close();chrome.kill();await new Promise(r=>server.server.close(r));}
