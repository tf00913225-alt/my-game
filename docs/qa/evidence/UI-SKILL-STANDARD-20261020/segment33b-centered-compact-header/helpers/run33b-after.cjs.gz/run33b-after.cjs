process.env.QA_HEADER_VARIANT='after';require('./run33b-comparison-header.cjs');
