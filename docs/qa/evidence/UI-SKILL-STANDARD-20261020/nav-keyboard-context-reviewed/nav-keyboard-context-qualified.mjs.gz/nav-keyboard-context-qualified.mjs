import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
import {ROOT,startServer,waitJson,Cdp,findChrome} from '../.github/scripts/runtime-browser-qa-support.mjs';

// Use the same isolated account and the real production loader as skill QA.
const skillQa=fs.readFileSync(path.join(ROOT,'.github/scripts/run-skill-progression-browser-qa.mjs'),'utf8');
const prepare=skillQa.match(/const PREPARE_RUNTIME=`([\s\S]*?)`;/)[1];
const viewport=JSON.parse(process.env.UI_READING_VIEWPORT||'[393,873]');
const sourceHead=process.env.GITHUB_SHA||execFileSync('git',['rev-parse','HEAD'],{cwd:ROOT,encoding:'utf8'}).trim();
const sourceDirty=!!execFileSync('git',['status','--porcelain'],{cwd:ROOT,encoding:'utf8'}).trim();
const out=path.join(ROOT,'artifacts/ui-skill-standard/batch2-nav-keyboard-context-qualified-'+sourceHead.slice(0,8),viewport.join('x'));if(fs.existsSync(out))throw Error('Output already exists');
fs.mkdirSync(out,{recursive:true});
const manifestBefore=fs.readFileSync(path.join(ROOT,'asset-manifest.json'),'utf8');const initialStatus=execFileSync('git',['status','--porcelain'],{cwd:ROOT,encoding:'utf8'}).trim();const server=await startServer();
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'functional-reading-'));
const port=9700+Math.floor(Math.random()*200);
const chrome=spawn(findChrome(),['--headless=new','--no-sandbox','--disable-gpu',`--remote-debugging-port=${port}`,`--user-data-dir=${profile}`,'about:blank'],{stdio:'ignore',windowsHide:true});
let c;const scenes=[];
const settle=()=>new Promise(r=>setTimeout(r,350));
const measure=String.raw`(selector)=>{
 const host=document.querySelector(selector);if(!host)throw Error('missing '+selector);
 const elementScale=e=>{let box=e;while(box&&!box.offsetWidth)box=box.parentElement;return box?box.getBoundingClientRect().width/box.offsetWidth:1;};
 const rows=[],overflow=[],controls=[];
 const tree=document.createTreeWalker(host,NodeFilter.SHOW_TEXT);
 while(tree.nextNode()){
  const n=tree.currentNode,e=n.parentElement,text=n.textContent.trim();
  if(!text||!e||e.closest('script,style,[aria-hidden="true"],.nav-sr-only,.inventory-title-plate-kicker'))continue;
  const s=getComputedStyle(e),r=e.getBoundingClientRect();
  if(!r.width||!r.height||s.visibility==='hidden'||s.display==='none')continue;
  if(/^[＋+×‹›◀▶▼▲▾◇◆…·—→←？]+$/.test(text))continue;
  const after=getComputedStyle(e,'::after');
  const replaced=parseFloat(s.fontSize)===0&&after.content&&after.content!=='none';
  const font=parseFloat(replaced?after.fontSize:s.fontSize)*elementScale(e);
  const button=!!e.closest('button,[role="tab"],[role="button"]');
  const primary=button&&e.matches('button,#creationSubmitLabel,.creation-next>span,.creation-back>span,.element-option .element-name')&&!e.closest('.home-test-tools');
  rows.push({text:text.slice(0,90),font,button,primary,selector:e.id?'#'+e.id:e.tagName.toLowerCase()+'.'+String(e.className).trim().replace(/\s+/g,'.'),parent:e.parentElement.id||e.parentElement.className});
 }
 for(const e of host.querySelectorAll('button,[role="tab"],[role="button"]')){
  const s=getComputedStyle(e),r=e.getBoundingClientRect();if(!r.width||!r.height||s.visibility==='hidden'||!e.textContent.trim())continue;
  const walker=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),bounds=[];
  while(walker.nextNode()){const n=walker.currentNode;if(!n.textContent.trim()||n.parentElement.closest('[aria-hidden="true"]'))continue;const range=document.createRange();range.selectNodeContents(n);bounds.push(range.getBoundingClientRect());}
  const t={left:Math.min(...bounds.map(b=>b.left)),right:Math.max(...bounds.map(b=>b.right)),top:Math.min(...bounds.map(b=>b.top)),bottom:Math.max(...bounds.map(b=>b.bottom))};
  const clamped=Array.from(e.querySelectorAll('*')).some(n=>parseInt(getComputedStyle(n).webkitLineClamp)>0);
  const labelControl=e.matches('button,[role="tab"]')&&!clamped;
  controls.push({label:(e.textContent||e.getAttribute('aria-label')||'').trim().slice(0,60),width:r.width,height:r.height,overflow:labelControl&&(t.left<r.left-1||t.right>r.right+1||t.top<r.top-1||t.bottom>r.bottom+1)});
 }
 for(const e of host.querySelectorAll('h1,h2,h3,.item-modal-name,.home-feature-modal-title,[role="tablist"]')){
  const r=e.getBoundingClientRect();if(!r.width||!r.height)continue;
  if(e.scrollWidth>e.clientWidth+1)overflow.push({text:e.textContent.trim().slice(0,60),width:r.width,scroll:e.scrollWidth,client:e.clientWidth});
 }
 return {rows,controls,overflow};
}`;
try{
 const target=(await waitJson(`http://127.0.0.1:${port}/json/list`)).find(t=>t.type==='page');
 c=new Cdp(target.webSocketDebuggerUrl);await c.send('Page.enable');await c.send('Runtime.enable');
 await c.send('Emulation.setDeviceMetricsOverride',{width:viewport[0],height:viewport[1],deviceScaleFactor:1,mobile:false});
 await c.send('Page.navigate',{url:server.url});await c.eval(prepare);
 await c.eval("(async()=>{await FourSymbolsFeatures.ensure('relic','functional-reading');await FourSymbolsFeatures.ensure('gameplay-core','functional-reading');})()");
 const capture=async(name,selector='#homeFeatureModal')=>{
  await settle();const data=await c.eval(`(${measure})(${JSON.stringify(selector)})`);
  assert.ok(data.rows.length||data.controls.length,name+': empty UI coverage');
  scenes.push({name,...data});fs.writeFileSync(path.join(out,'all-text.json'),JSON.stringify(scenes,null,2));
  const image=await c.send('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(out,name+'.png'),Buffer.from(image.data,'base64'));
  console.log(name+': '+data.rows.length+' text nodes, '+data.rows.filter(x=>x.font<12.9).length+' below minimum');
 };
 const tap=async selector=>{
  const point=await c.eval(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e)return null;const r=e.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,hit=document.elementFromPoint(x,y);return {x,y,hit:hit===e||e.contains(hit),label:e.textContent.trim(),rect:r.toJSON(),disabled:!!e.disabled};})()`);
  assert.ok(point?.hit&&!point.disabled&&point.rect.width>=44&&point.rect.height>=44,'real44 input is blocked: '+selector+' '+JSON.stringify(point));
  await c.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:point.x,y:point.y}]});
  await c.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await settle();
 };


 await c.send('Emulation.setFocusEmulationEnabled',{enabled:true});
 await c.eval("(async()=>{await FourSymbolsFeatures.ensure('boss-tower','nav-context-keyboard');closeHomeFeature();showPage('home');})()");await settle();
 const steps=[];const write=()=>fs.writeFileSync(path.join(out,'keyboard-steps.json'),JSON.stringify(steps,null,2));
 await c.eval("window.__navQaKeyEvents=[];for(const type of ['keydown','keypress','keyup','click'])document.addEventListener(type,e=>{if(e.target.closest?.('#bottomNav'))__navQaKeyEvents.push({type,key:e.key,trusted:e.isTrusted,target:e.target.id||e.target.getAttribute('aria-label')});},true)");const key=async(name,code,vk)=>{await c.send('Input.dispatchKeyEvent',{type:name==='Enter'?'keyDown':'rawKeyDown',key:name,code,windowsVirtualKeyCode:vk,...(name==='Enter'?{text:'\r',unmodifiedText:'\r'}:{})});await c.send('Input.dispatchKeyEvent',{type:'keyUp',key:name,code,windowsVirtualKeyCode:vk});};
 const focus=async(selector,name)=>{let found=false,count=0;for(;count<=160;count++){found=await c.eval('document.activeElement?.matches('+JSON.stringify(selector)+')');if(found)break;if(count===160)throw Error('bounded Tab target missing '+selector);await key('Tab','Tab',9);await new Promise(r=>setTimeout(r,15));}const data=await c.eval("(()=>{const e=document.activeElement,r=e.getBoundingClientRect(),h=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2),s=getComputedStyle(e);return{tag:e.tagName,label:e.getAttribute('aria-label')||e.innerText,rect:r.toJSON(),focusVisible:e.matches(':focus-visible'),outline:s.outlineStyle+' '+s.outlineWidth+' '+s.outlineColor,hit:h===e||e.contains(h),disabled:!!e.disabled};})()");assert(data.focusVisible&&data.hit&&!data.disabled&&data.rect.width>=44&&data.rect.height>=44&&data.rect.top>=0&&data.rect.bottom<=viewport[1]+1,'keyboard target invisible '+JSON.stringify(data));steps.push({kind:'native-Tab',name,selector,count,...data});write();await capture(name+'-focus','#bottomNav');};
 const enter=async()=>{await key('Enter','Enter',13);await settle();};
 const state=async(name,expected)=>{const data=await c.eval("(()=>{const nav=bottomNav,shell=nav.parentElement,r=n=>n.getBoundingClientRect().toJSON();return{page:document.querySelector('#game-ui > .page.active, #game-content .page.active')?.id,context:nav.dataset.navContext,shells:document.querySelectorAll('.native-bottom-nav-layer').length,parent:shell.parentElement.id,hidden:shell.hidden,battleActive:!!battleActive,buttons:[...nav.children].map(n=>{const b=r(n),h=document.elementFromPoint(b.left+b.width/2,b.top+b.height/2);return{label:n.getAttribute('aria-label'),handler:n.getAttribute('onclick'),rect:b,hit:h===n||n.contains(h)};})};})()");fs.writeFileSync(path.join(out,'last-state.json'),JSON.stringify({expected,data,events:await c.eval('__navQaKeyEvents')},null,2));assert.equal(data.context,expected);assert.equal(data.shells,1);assert.equal(data.parent,'game-overlay-layer');assert.equal(data.hidden,false);assert.equal(data.battleActive,false);assert(data.buttons.every(b=>b.hit&&b.rect.width>=44&&b.rect.height>=44));steps.push({kind:'context',name,...data});write();await capture(name,'#bottomNav');};
 const back=async(name,expected)=>{await focus('#bottomNav button[aria-label=返回]',name);await enter();await state(name+'-returned',expected);};
 await focus('#trainingNav','training-entry');await enter();await state('training','training');await back('training-back','main');
 await focus('#bossNav','gameplay-entry');await enter();await state('gameplay','gameplay:gameplayPage');
 await focus('.gameplay-mode-card.boss','boss-entry');await enter();await state('boss-overview','gameplay:bossPage');await back('boss-back','gameplay:gameplayPage');
 await focus('.gameplay-mode-card.tower','tower-entry');await enter();await state('tower-overview','gameplay:towerPage');await back('tower-back','gameplay:gameplayPage');await back('gameplay-back','main');

const loaded=await c.eval("performance.getEntriesByType('resource').map(e=>new URL(e.name).pathname).filter(p=>/\\.(css|js)$/.test(p))");
 const finalStatus=execFileSync('git',['status','--porcelain'],{cwd:ROOT,encoding:'utf8'}).trim();assert.equal(finalStatus,initialStatus);assert.equal(fs.readFileSync(path.join(ROOT,'asset-manifest.json'),'utf8'),manifestBefore);assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:ROOT,encoding:'utf8'}).trim(),sourceHead);
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({head:sourceHead,dirty:sourceDirty,viewport,initialStatus,finalStatus,manifestUnchanged:true,loaded,scenes:scenes.map(s=>({name:s.name,small:s.rows.filter(x=>x.font<12.9),overflow:s.overflow,clippedControls:s.controls.filter(x=>x.overflow)})),scope:'After presentation only, independent review pending; original isolated fixture and real production loader; no battle or transaction'},null,2));
}catch(e){fs.writeFileSync(path.join(out,'failure.json'),JSON.stringify({head:sourceHead,error:String(e.stack||e)},null,2));if(c)try{fs.writeFileSync(path.join(out,'failure.png'),Buffer.from((await c.send('Page.captureScreenshot',{format:'png'})).data,'base64'));}catch{}throw e;}finally{try{execFileSync('taskkill',['/PID',String(chrome.pid),'/T','/F'],{stdio:'ignore',windowsHide:true});}catch{chrome.kill();}c?.close();let removed=false;try{if(!path.resolve(profile).startsWith(path.resolve(os.tmpdir())+path.sep))throw Error('profile path');fs.rmSync(profile,{recursive:true,force:true,maxRetries:3,retryDelay:100});removed=!fs.existsSync(profile);}catch{}fs.writeFileSync(path.join(out,'cleanup.json'),JSON.stringify({profileRemoved:removed,runtimeRestoreExact:false,scope:'Original isolated QA only'}));await new Promise(r=>server.server.close(r));}
