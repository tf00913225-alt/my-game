// Preparation only: imports never launch Chrome or alter application state.
export const skillIdsByElement={
 fire:['flameSlash','fireCritical','explosiveFlurry','dragonSlash','fireRocket','blazeSpell','flameTornado','phoenixCry','rage','fireSoulResonance','bloodBurnArt','fireEX'],
 water:['waterKnife','frostPunch','iceSpin','frostCrush','waterBall','floodBeast','iceArrowRain','healSpell','revive','freeze','purifyMind','waterEX'],
 wind:['stormFist','stormFlurry','windCrossSlash','dizzyFist','windSpell','stormCircle','windHowlLightning','stormRain','dodgeSkill','stealthSkill','dinghaishenzhen','windEX'],
 earth:['stoneSlash','petrifyFist','stoneBreakSky','earthquakeCrush','stoneThrow','sandWind','flyingSandStrike','dustStorm','rockWall','earthShield','barrier','earthEX']
};
// Run through the existing CDP eval after formal loaders and fixture prep.
export const inspectExpression=`(()=>{
 if(!window.__v17364SkillProgressionInstalled||!window.FourSymbolsSkillProgressionCore)throw Error('Final skill Owner missing');
 const loadout=characterSkillLoadouts[currentSkillCharacter],character=getSkillCharacterObject(currentSkillCharacter);
 const cards=[...document.querySelectorAll('.skill-row-detail-link')].map(el=>{const m=el.getAttribute('onclick')?.match(/^showSkillDetail\\('([^']+)'\\)$/);if(!m)throw Error('Unexpected detail caller');const id=m[1],skill=skillDatabase[id];if(!skill)throw Error('Unknown card '+id);return{id,name:skill.name,element:skill.element,description:skill.description,maxLevel:skill.maxLevel,learnLevel:skill.learnLevel,level:loadout?.skillLevels?.[id]||0,eligibility:getSkillLearnEligibilityForUi(character,skill,loadout?.skillLevels||{}),rect:el.getBoundingClientRect().toJSON()};});
 return{characterKey:currentSkillCharacter,cards,allIds:Object.keys(skillDatabase).filter(id=>Object.hasOwn(skillDatabase[id],'learnLevel')),detailOpen:document.getElementById('skillDetailModal').classList.contains('show')};
})()`;
export const detailSnapshotExpression=`(()=>{const b=document.getElementById('skillDetailStats'),m=document.getElementById('skillDetailModal');return{elementLabel:[...b.querySelectorAll(".v17364-progression-detail>div")].find(e=>e.querySelector("strong")?.textContent==="技能元素")?.querySelector("span")?.textContent,name:document.getElementById('skillDetailName').textContent,text:b.textContent,open:m.classList.contains('show'),scrollTop:b.scrollTop,scrollHeight:b.scrollHeight,clientHeight:b.clientHeight,levelRows:b.querySelectorAll('.skill-detail-level-row').length,progressionRows:b.querySelectorAll('.v17364-progression-detail>div').length};})()`;
export const identitySnapshotExpression=`JSON.stringify({loadouts:characterSkillLoadouts,player,player2,player3,storage:Object.fromEntries(Object.keys(localStorage).map(k=>[k,localStorage.getItem(k)]))})`;
// Transparent observation of the existing synchronous handlers. Never intercept save,
// clocks or background timers; full sequence snapshots remain separate evidence.
export const installHandlerObservationExpression=`(()=>{
 if(window.__segment25HandlerObservation)throw Error('Observer already installed');
 const records=[],original={show:showSkillDetail,close:closeSkillDetail};
 const snapshot=()=>${identitySnapshotExpression};
 const differences=(a,b)=>{const x=JSON.parse(a),y=JSON.parse(b),identityKeys=[...new Set([...Object.keys(x),...Object.keys(y)])].filter(k=>k!=='storage'&&JSON.stringify(x[k])!==JSON.stringify(y[k])),storageKeys=[...new Set([...Object.keys(x.storage),...Object.keys(y.storage)])].filter(k=>x.storage[k]!==y.storage[k]);return{identityKeys,storageKeys};};
 function wrap(name,fn){return function(...args){const startedAt=performance.now();let before,beforeError;try{before=snapshot();}catch(error){beforeError=String(error.message||error);}let thrown;try{return Reflect.apply(fn,this,args);}catch(error){thrown=error;throw error;}finally{try{const after=snapshot();records.push({handler:name,args:args.map(v=>typeof v==='string'||typeof v==='number'?v:typeof v),startedAt,finishedAt:performance.now(),sameTaskUnchanged:!beforeError&&before===after,...(beforeError?{identityKeys:[],storageKeys:[],observationError:beforeError}:differences(before,after)),before,after,threw:!!thrown,error:thrown?String(thrown.message||thrown):null});}catch(observationError){records.push({handler:name,startedAt,observationError:String(observationError.message||observationError),sameTaskUnchanged:false});}}};}
 const wrapped={show:wrap('showSkillDetail',original.show),close:wrap('closeSkillDetail',original.close)};
 showSkillDetail=wrapped.show;closeSkillDetail=wrapped.close;
 window.__segment25HandlerObservation={records,restore(){const exactBeforeRestore=showSkillDetail===wrapped.show&&closeSkillDetail===wrapped.close;showSkillDetail=original.show;closeSkillDetail=original.close;const restored=showSkillDetail===original.show&&closeSkillDetail===original.close;delete window.__segment25HandlerObservation;return{exactBeforeRestore,restored};}};
 return{installed:true};
})()`;
export const restoreHandlerObservationExpression=`window.__segment25HandlerObservation?.restore()||{notInstalled:true}`;
